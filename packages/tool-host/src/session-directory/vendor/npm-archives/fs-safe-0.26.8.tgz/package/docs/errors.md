# Errors

Every failure that's the library's job to surface lands as an `FsSafeError` with a closed `code` union you can branch on. Catch by code, not by message text — messages may change, codes will not.

Result-based APIs are an exception to throwing: [`pathScope().ensureDir()`](path-scope.md#ensuredir-rel-options)
and `ensureDirectoryWithinRoot()` return operational failures as
`{ ok: false, error: string, diagnostic: FsSafeError }`. The diagnostic uses
`helper-failed` / `operational`, retains the exact native error in `cause`, and
has the same message as `error`. Its display text names the native code/syscall
when available but omits raw paths and native messages. Policy failures keep
the string-only result without `diagnostic`; other `pathScope` methods do not
gain this field. Directory preparation can partially complete before failing.

Path and archive-entry details embedded in diagnostics escape control characters
as `\\uXXXX` sequences. This keeps attacker-controlled names on one log line;
the escaped message is for diagnosis, not for reconstructing the original path.

```ts
import { FsSafeError, type FsSafeErrorCode } from "@openclaw/fs-safe";
```

## Shape

```ts
class FsSafeError extends Error {
  readonly name: "FsSafeError";
  readonly code: FsSafeErrorCode;
  readonly category: "policy" | "operational";
  readonly details?: Readonly<Record<string, unknown>>;

  constructor(
    code: FsSafeErrorCode,
    message: string,
    options?: { cause?: unknown; details?: Readonly<Record<string, unknown>> },
  );
}
```

`cause` is available through the standard `Error` `cause` property when the failure was triggered by a `NodeJS.ErrnoException` (e.g. a wrapped `EACCES`). Inspect it for the original `code` / `errno` / `syscall` if you need finer-grained reporting.

Native Windows failures, including private directory and file creation failures,
retain the original numeric Win32 error in `errno` (for example, 183 for
`ERROR_ALREADY_EXISTS` or 5 for `ERROR_ACCESS_DENIED`). This also applies to the
Windows security command fallback. A wrapped failure retains that number on its
original `cause`; the semantic `FsSafeError.code` remains the contract. Policy
checks and preflight rejections that do not execute a failing Windows operation
have no Win32 error number. Node-managed filesystem errors retain Node's own errno.

Guarded write preparation describes permission, read-only filesystem, and disk-space
failures with messages such as `permission denied (EACCES)` or
`no space left on device (ENOSPC)`. Other errno failures include their code in
`filesystem write failed (EIO)`. These wrappers retain the existing `invalid-path`
code and `policy` category for compatibility, along with the original `cause`;
they do not expose native message text or paths. Already-classified `FsSafeError`
instances and missing-path errors keep their existing classification.
Disk-space diagnostics also survive combined publication and disposal failures,
including `SuppressedError` and `AggregateError`. They retain the original cause
graph and cleanup/publication receipts, without changing the compatibility code
or category. An uncertain native rename still reports indeterminate publication
and a preserved stage; `ENOSPC` does not prove that publication never happened.

Descriptor exhaustion during writes uses `helper-failed` / `operational` and
names `EMFILE` (process descriptor limit) or `ENFILE` (system descriptor limit)
in its message. The original error remains in `cause`, including any
`SuppressedError` linking publication and disposal failures. When native rename
has an uncertain outcome, the message explicitly reports indeterminate
publication and a preserved stage; `details.publication` and `details.cleanup`
retain that receipt. Descriptors are still closed. An errno alone does not prove
that publication never happened, so this diagnostic does not authorize removing
the stage or retrying the write. Existing boundary/policy errors keep their codes.

`details` is an operation-specific receipt, not an alternate error code. For
example, `publishFileExclusive()` uses it to report the failing phase, created
target identity, cleanup decision, and failed directory-sync outcome. Narrow
by `code` and a documented details field before consuming it; do not assume all
`FsSafeError` instances carry the same keys.

`replaceFileAtomic({ copyFallbackRestore: "restore-original" })` reports a
failed copy fallback with the exported `ReplaceFileAtomicRestoreFailureDetails`
shape:

```ts
type ReplaceFileAtomicRestoreFailureDetails = {
  cleanup: "restored" | "restore-failed";
};
```

Both outcomes use `code: "helper-failed"`. `"restored"` means the original
snapshot was written back and fsynced through the pinned destination handle.
`"restore-failed"` means both the replacement and recovery failed; `cause` is
an `AggregateError` containing both failures. A snapshot that exceeds
`maxRestoreBytes` fails earlier with `too-large` and does not overwrite the
destination.

`category` separates caller-policy failures from operational failures:

- `"policy"` — unsafe input or target state rejected by a safety policy, such as `outside-workspace`, `symlink`, `hardlink`, or `too-large`.
- `"operational"` — routine filesystem outcomes or environment/runtime failures, such as `not-found`, `not-empty`, `not-removable`, helper startup, platform support, timeout, or unverifiable permissions.

Routine absence or inability to remove a path does not by itself indicate a
filesystem boundary violation. Branch on the specific code when the distinction
between those operational outcomes matters.

The operational set is exactly `helper-failed`, `helper-unavailable`,
`not-empty`, `not-found`, `not-removable`, `permission-unverified`, `read-failed`,
`timeout`, and `unsupported-platform`. Every other current `FsSafeErrorCode`, including
`store-reentrant-update`, is categorized as `policy`.

## Code union

```ts
type FsSafeErrorCode =
  | "already-exists"
  | "denied-path"
  | "device-path"
  | "hardlink"
  | "helper-failed"
  | "helper-unavailable"
  | "insecure-permissions"
  | "invalid-path"
  | "not-empty"
  | "not-file"
  | "not-found"
  | "not-owned"
  | "not-removable"
  | "outside-workspace"
  | "path-alias"
  | "path-mismatch"
  | "permission-unverified"
  | "read-failed"
  | "secret-exists"
  | "store-reentrant-update"
  | "symlink"
  | "timeout"
  | "too-large"
  | "unsupported-platform";
```

## Code reference

Create-only Root writes to an existing regular file or directory report
`already-exists` in every native mode, including atomic and streamed creation.
Policy failures such as an explicit symlink rejection or a denied path retain
their precedence. A non-directory ancestor still reports its path/type failure;
it is not an existing destination.

| Code | When it fires | Common causes |
|---|---|---|
| `already-exists` | `create()`, `createJson()`, `move({ overwrite: false })`. | Target file or directory already at the destination. |
| `denied-path` | A root mutation matched `denyMutations.paths` or `denyMutations.prefixes`. | Caller configured application-sensitive paths that must not be written, removed, moved, or created. |
| `device-path` | A read/open target is a known unsafe device or process-fd path. | `/dev/zero`, `/dev/random`, `/dev/stdin`, `/dev/fd/*`, `/proc/*/fd/*`, or a Windows reserved device name. |
| `hardlink` | Read or copy with `hardlinks: "reject"` saw `nlink > 1`. | File is hardlinked — possibly an alias of an out-of-tree inode. |
| `helper-failed` | A native mechanism or multi-step operational helper failed. | Inspect `cause` and any operation-specific `details`; retrying may be unsafe if the operation partially completed. |
| `helper-unavailable` | A required native binding or bounded primitive could not be loaded. | Unsupported platform, omitted/missing/incompatible platform package, `FS_SAFE_NATIVE_MODE=off`, or a no-clobber `Root.move()` without safe native parent admission. `auto` falls back only where a safe fallback exists. |
| `insecure-permissions` | A secure file or path permission check found a mode/ACL that allows broader access than requested. | File or directory is group/world writable/readable; Windows ACL grants broad read. |
| `invalid-path` | Input was empty, contained NUL, was an unparseable URL, or otherwise unusable; a FileStore key used a noncanonical spelling. | Noncanonical FileStore aliases, backslashes, or complete parent segments; a network path on Windows; a drive-relative segment in a portable relative path or store key; or a leading drive-relative spelling such as `C:name` used as a Root destination. Existing-object Root lookups retain broader confined path compatibility, including legal POSIX drive-like names. |
| `not-empty` | Nonrecursive `remove()` on a non-empty directory, or new children appeared during recursive removal. | Use bounded `recursive: true` removal or coordinate concurrent writers. |
| `not-file` | Read or copy targeted a non-regular file, or a path walk found a non-directory ancestor. | Target was a directory, FIFO, socket, device, or an existing file was followed by another segment. |
| `not-found` | The target does not exist (or its parent does not, with `mkdir: false`). | Typical missing-file case. |
| `not-owned` | A secure file owner check failed. | File is owned by another UID. |
| `not-removable` | `remove()` couldn't inspect a directory stream or `unlink`/`rmdir` for a reason other than non-empty. | Permissions, device busy, immutable bit; the original filesystem error remains in `cause`. |
| `outside-workspace` | Path resolves outside the configured root. | `..` traversal; absolute path outside the root; symlink resolved out. |
| `path-alias` | A path alias check failed (e.g. canonical-real-path moved out of the root). | Symlink resolution lands outside the root. |
| `path-mismatch` | Post-open identity check failed: the opened fd does not match the resolved path. | TOCTOU — something else swapped the path between resolve and open. |
| `permission-unverified` | A secure file check could not verify required permissions. | Windows ACL inspection failed; POSIX ownership/mode was unavailable. |
| `read-failed` | A validated file could not be read because of an operational filesystem or device failure. | I/O error, media failure, or another runtime read failure; inspect `cause`. |
| `secret-exists` | `createSecretFileAtomic()` found an existing final path. | First-writer-wins secret creation lost a race or the credential was already initialized. |
| `store-reentrant-update` | A `JsonStore.update()` callback called `update()` or `updateOr()` for the same canonical store before returning. | Reentrant mutation would deadlock or lose an update; return the complete next value from the outer callback. |
| `symlink` | Path component is a symlink, policy is `reject`. | Caller followed a symlink they shouldn't have, or `symlinks: "reject"` is set. |
| `timeout` | An operation with a wall-clock budget overran. | Secure file read or timed operation exceeded `timeoutMs`. |
| `too-large` | A read, bounded walk, or recursive removal exceeded its configured budget. | Review the expected file or tree size before increasing the limit; recursive removal may have completed earlier entries. |
| `unsupported-platform` | The platform or filesystem cannot perform the requested operation. | `createCloneSource` and `copyTree({ clone: "always" })` require native cloning support. The default `copyTree({ clone: "auto" })` selects portable byte copying when cloning is unavailable; unsupported source contents or metadata still fail. See [directory copying](copy.md) for backend limits and fallback behavior. |

Secret writes reject invalid `mode` / `dirMode` values with `invalid-path` before directory creation. Existing secret directories with a mode different from the requested `dirMode` report `insecure-permissions` without chmod; a created directory whose descriptor ownership no longer matches its initializing effective user reports `not-owned`.

Pathname `sha256File()` and `sha256FileSync()` also report `path-mismatch` when
pre-open, descriptor, or current-path identity remains unknown after one bounded
Windows retry, even if the file is benign. Neither reopens to recover identity.
Preview symlinks report `symlink`, preview or descriptor non-files report
`not-file`, and a current-path symlink or non-file reports `path-mismatch`.

## Branching

```ts
import { FsSafeError } from "@openclaw/fs-safe";

try {
  await fs.write("../escape.txt", "x");
} catch (err) {
  if (!(err instanceof FsSafeError)) throw err;
  switch (err.code) {
    case "outside-workspace":
      return reply(400, "path escapes workspace");
    case "already-exists":
      return reply(409, "exists");
    case "too-large":
      return reply(413, "too large");
    case "not-found":
      return reply(404, "missing");
    case "symlink":
    case "device-path":
    case "hardlink":
    case "path-mismatch":
    case "path-alias":
      return reply(400, "unsafe path");
    default:
      throw err;
  }
}
```

The `default` above deliberately rethrows unknown codes, so it remains safe as
the union grows. If you want the compiler to flag every newly added code, end
an exhaustive switch with a `never` assertion instead of a general `default`.

## Distinguishing from `NodeJS.ErrnoException`

Some failures bubble up as native Node errors (e.g. `EACCES`, `EPERM`, `EISDIR`, `EBUSY`) when they don't map cleanly to a library code. Inspect both:

```ts
import { FsSafeError } from "@openclaw/fs-safe";

try {
  await op();
} catch (err) {
  if (err instanceof FsSafeError) {
    handleFsSafe(err);
    return;
  }
  const code = (err as NodeJS.ErrnoException).code;
  if (code === "EACCES" || code === "EPERM") {
    handleAccess();
    return;
  }
  throw err;
}
```

A common pattern is to wrap your domain code in a single try/catch that maps both shapes to your application's typed error format.

On Windows, access-denied failures from native root/open filesystem operations
use `EPERM` to match Node/libuv and the JavaScript fallback. Security-descriptor
inspection has its own failure surface. Older fs-safe versions could report
`EACCES` for the same root/open condition, so consumers spanning versions
should accept both codes.

## Specialty errors

A handful of helpers throw their own typed errors instead of `FsSafeError`:

- `JsonFileReadError` — thrown by [`readJson`](json.md). Carries `cause` so you can distinguish missing (`ENOENT`) from invalid (`SyntaxError`).
- `ArchiveLimitError` — thrown by [`extractArchive`](archive.md) when an archive size, entry count, path depth, metadata, or extracted-byte budget is exceeded. The `code` field uses the string values exposed by `ARCHIVE_LIMIT_ERROR_CODE` (for example `archive-entry-path-components-exceeds-limit`).
- `ArchiveSecurityError` — thrown by extraction when entry policy or destination safety fails. Entry codes are `entry-path`, `entry-link`, and `entry-filtered`; destination codes cover non-directory, symlink, and symlink-traversal failures.

These are exported from their respective subpaths.

## Why `FsSafeError`?

Two reasons it isn't a richer hierarchy of subclasses:

1. **Switch on `code`, don't `instanceof` a tree.** `code` is a closed string union the TypeScript compiler can exhaust-check. Subclasses make `instanceof` ladders that drift over time.
2. **One catch handler.** Library callers often want a single "is this an `fs-safe` failure?" gate before deciding what to do — `instanceof FsSafeError` plus a switch is the cleanest expression of that.

## See also

- [`root()`](root.md) — every method documents the codes it can throw.
- [Reading](reading.md) — read-path codes.
- [Writing](writing.md) — write-path codes.
- [Archive extraction](archive.md) — `ArchiveLimitError` and `ArchiveSecurityError`.

## Unsupported no-replace moves

`isNoReplaceUnsupported(error)` is exported from `@openclaw/fs-safe` and
`@openclaw/fs-safe/errors`. It recognizes a `helper-unavailable` `FsSafeError`
with `details.capability === "rename-noreplace"`. This includes strict native
publication refusals and a Root file move whose link fallback is also unavailable
(`details.fallback === "link-unlink"`, `details.fallbackCapability === "linkat"`).
It does not classify a missing native addon, unrelated permission errors, or
post-publication failures. Once no-replace rename has been rejected, a denied
or unsupported `linkat` fallback (`EPERM`, `EOPNOTSUPP`, `EMLINK`, `EXDEV`,
or `ENOSYS`) also fails with this classification. `EPERM` can reflect source
permissions or inode flags rather than a filesystem-wide lack of hard links;
the fallback is unavailable for this move. No link-capability cache is populated.
Consumers need not inspect internal native cause codes.
The classifier is diagnostic; it does not authorize a replacing retry.

When a Root file move's link/unlink fallback fails after creating the target,
`details.operation` is `"move"`, `details.fallback` is `"link-unlink"`, and
`details.publication` is `"published"` (the link was created, not a guarantee
that a concurrent actor has left it unchanged). `details.sourceRemoval` is:

| Value | Observation |
| --- | --- |
| `"not-attempted"` | Identity or link-pair verification failed; source unlink was refused (`path-mismatch`). |
| `"still-linked"` | Unlink failed and both original inode links were reverified (`helper-failed`). |
| `"unverified"` | Unlink failed and the current pair could not be verified (`helper-failed`). |
| `"removed"` | Source unlink succeeded but final target verification failed (`helper-failed`). |

The target is never deleted to roll back these failures. These are observations,
not locks; inspect the names and identities before recovery. Interrupted processes
can likewise leave both links, and default hardlink rejection remains enabled.
