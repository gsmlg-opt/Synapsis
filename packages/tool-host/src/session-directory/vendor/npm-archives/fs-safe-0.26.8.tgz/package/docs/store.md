---
title: Store
description: "Overview of @openclaw/fs-safe/store: fileStore, fileStoreSync, and jsonStore."
---

# `@openclaw/fs-safe/store`

The `store` subpath bundles two managed wrappers around the same safe-write primitives `root()` uses:

```ts
import {
  ensureJsonDurableQueueDirs,
  fileStore,
  fileStoreSync,
  jsonStore,
  loadPendingJsonDurableQueueEntries,
  resolveJsonDurableQueueEntryPaths,
  writeJsonDurableQueueEntry,
  type FileStore,
  type FileStoreOptions,
  type FileStoreSync,
  type JsonStore,
  type JsonStoreOptions,
} from "@openclaw/fs-safe/store";
```

| Helper | Use it for |
|---|---|
| [`fileStore()`](file-store.md) | Multi-file directories with safe relative paths, size limits, atomic replacement, stream writes, copy-in, and TTL-based pruning. |
| `fileStoreSync()` | Synchronous variant of `fileStore()` for places that genuinely cannot await. |
| [`jsonStore()`](json-store.md) | A single keyed JSON state file with explicit fallback, atomic writes, and optional sidecar locking around read-modify-write updates. |
| Durable JSON queue helpers | Append/load/ack JSON entry files using atomic writes and delivered markers. |
| [Private file-store mode](file-store.md#private-mode) | `fileStore({ private: true })` for credentials, tokens, and per-agent state at `0600` files under `0700` directories. |

`fileStore().json("rel.json")` and `jsonStore({ filePath })` are intentionally separate primitives. Use `fileStore().json(...)` when JSON state lives alongside other files in the same managed directory; use `jsonStore({ filePath })` when you have one trusted path, resolved to an absolute path at construction, and want the keyed JSON shape directly.

## Picking a shape

- **Multi-file directory under one root** — reach for `fileStore()`. It exposes `write`, `writeJson`, `writeText`, `writeStream`, `read*`, `open`, `copyIn`, `remove`, and `pruneExpired` against safe relative paths.
- **One JSON state file** — reach for `jsonStore({ filePath })`. Its `update()` and `updateOr()` methods cover the merge-into-defaults and read-modify-write cases.
- **Credentials or tokens** — pass `private: true` to `fileStore()`. Same store shape; writes route through the secret-file atomic path with `0600`/`0700` permissions.
- **Durable work queues** — use the durable JSON queue helpers when each work item is a standalone JSON file and acknowledgement is represented by moving it through a short-lived `.delivered` marker.

## Durable JSON queues

The durable queue helpers are intentionally low-level. They do not decide retry,
dedupe, or recovery policy; they just provide the filesystem mechanics that
several queue implementations otherwise rewrite by hand.

```ts
await ensureJsonDurableQueueDirs({ queueDir, failedDir });

const paths = resolveJsonDurableQueueEntryPaths(queueDir, id);
await writeJsonDurableQueueEntry({
  filePath: paths.jsonPath,
  entry,
  tempPrefix: "queue",
});

const pending = await loadPendingJsonDurableQueueEntries({ queueDir, tempPrefix: "queue" });
```

`id` must be a single safe path segment: non-empty, not dot-prefixed, and made
from letters, numbers, `_`, `-`, and `.`. Slashes, backslashes, NUL bytes, `.`,
`..`, and Windows reserved device names such as `CON`, `NUL`, and `COM1` are
rejected on every platform so queue IDs remain portable. Temporary filenames
continue to suffix reserved stems (for example, `CON.txt` becomes `CON_.txt`).

Use `ackJsonDurableQueueEntry()` after durable processing succeeds and
`moveJsonDurableQueueEntryToFailed()` when the caller wants to quarantine an
entry for inspection.

Loading serializes consumers for one ID through a sidecar lock, then creates `processingPath` with a no-replace hardlink and retires the source through a recoverable sibling record. Whichever producer generation occupies `.json` at the hardlink operation becomes the claim; a replacement published afterward remains pending. After a crash, `.processing` is retried before that pending replacement. Transfer locks are fail-closed and are never reclaimed automatically, so an operator must remove a proven-stale lock after a hard process crash. Acknowledgement atomically moves `.processing` through the short-lived `.delivered` marker, and existing delivered markers are cleaned during batch loading. `ackJsonDurableQueueEntry()` rejects while `.json` exists without a processing claim: callers that previously paired direct `readJsonDurableQueueEntry()` with acknowledgement must load through `loadJsonDurableQueueEntry()` before processing so acknowledgement is generation-bound.

Queue and failed directory creation fsyncs every newly-created parent edge from the leaf toward the trusted root. Enqueue and migration writes fsync the temp file and parent; claim, acknowledgement, quarantine, delivered-marker cleanup, and retirement transitions fsync every affected directory and propagate real sync failures. A transition may already be visible when a post-mutation sync fails, so retry the same operation to complete its crash-recovery state. Acknowledgement retries resync the queue directory even when both `.processing` and `.delivered` marker names are already absent, before reporting completion or rejecting a newer pending generation; quarantine retries with only failed evidence resync that destination before repairing the vanished queue source.

`writeJsonDurableQueueEntry()` and migrations share strict parent synchronization inside the atomic writer's retained descriptor and per-path serialization lifetime, followed by published-file identity verification. If sync fails after publication, the write rejects without rolling back the published JSON; retrying `writeJsonDurableQueueEntry()` writes the entry again and must complete its own sync. Loader retries resync an existing processing claim's parent under the transfer lock before calling `read`, even when a version-dependent callback would no longer request migration. Fresh claims and same-directory source retirement already complete that sync. This is not a rollback, deduplication, or exactly-once guarantee. The generic `replaceFileAtomic({ syncParentDir: true })` option remains best-effort.

The direct queue writer accepts trusted relative paths. On Windows it anchors
an ordinary drive-relative `filePath` before publication and strict parent
sync. Other queue lifecycle APIs retain their own root/path admission contracts.

Batch loading skips invalid entry names, malformed, oversized, or unreadable entry content, and caller `read` callback failures. Initially unowned pending entries (hardlinks or unverifiable identities), symlinks, non-files, and absent pending entries are also skipped. Claim, transfer-lock, retirement, and migration write/publication/durability failures reject the batch with the original error, even if earlier entries succeeded. Migration in both loaders strictly syncs the parent directory after successful publication. Visible transitions and earlier processing claims remain for retry; a rejected batch does not acknowledge or roll them back.

Failed destinations are create-only. Quarantine publishes the claimed file by hardlink, so the queue and failed directories must share a filesystem with hardlink support. If `failed/<id>.json` already exists, quarantine rejects while preserving both that earlier evidence and the current claimed entry instead of overwriting either file. The `read` callback continues to receive the logical `.json` path even though bytes are read and migrations are written through the claimed path.

Claim, quarantine, and retirement recovery require hardlinks. If a link syscall
is refused with `EACCES`, `EPERM`, `EXDEV`, `ENOTSUP`, `EOPNOTSUPP`, or `ENOSYS`,
the operation rejects with `FsSafeError("helper-unavailable")` and retains the
original error in `cause`. This includes Android/Termux environments that deny
hardlinks. The refusal leaves the pending entry, processing claim, or retirement
record intact for retry after the capability or permission problem is resolved;
it does not acknowledge delivery. Batch loading propagates this capability
failure too. The queue does not fall back to copying or overwriting rename:
those operations cannot preserve its shared-inode recovery and create-only
collision evidence. Enqueue alone does not prove that an entry can be claimed.

The [link-free queue design](queue-link-free-design.md) describes an unimplemented
v2 candidate and its mixed-version barriers. It does not change these helpers or
provide Android/Termux queue support.

Migrations stay bound to the exact processing file opened for that load. The
read descriptor remains pinned while the callback runs outside the transfer
lock; after the callback returns, migration reacquires the lock and rechecks the
claim before publication. If another consumer acknowledged, quarantined, or
replaced that claim, the migration rejects with `FsSafeError("path-mismatch")`
and leaves the newer generation or failed evidence intact. A stale migration
rejects both single and batch loads; ordinary callback failures retain their
existing single-load rejection and batch-skip behavior. A caller or migration
error with code `ENOENT` is still a failure, not a missing queue entry; only a
claim that is absent or disappears before reading returns `null` from a single load.

If closing the read descriptor also fails, the original read, validation,
callback, or migration failure keeps precedence, including non-Error rejection
values. A close failure without an earlier failure is reported through the same
loader policy: direct reads and single loads reject, while batch loads skip it
unless migration has started.

On Windows, migration releases its read pin once at this publication boundary
because an open target can block replacement. It rechecks the exact pathname
identity after the asynchronous close while still holding the transfer lock.
POSIX retains the read pin through publication. Other readers keep ownership
of their handles; Windows sharing denials still reject and can be retried after
those readers close.

Generation arbitration requires consumers to use the transfer lock. As with
[atomic writes](atomic.md#beforerename), identity checks and pathname replacement
are separate operations; use a trusted writable parent or OS isolation against
processes that ignore the lock and mutate queue paths concurrently.

Queue entry reads verify lossless file identities before opening, on the opened
descriptor, and at the current pathname before reading bytes. POSIX opens are
nonblocking, so a raced FIFO is rejected rather than stalling a consumer. On Windows, an
unknown identity gets one bounded reinspection; persistent ambiguity or a
mismatch rejects with `queue entry changed during read`. Each inspection still
rejects non-files, symlinks, hardlinks, and entries over the byte limit.

## Related pages

- [`fileStore`](file-store.md) — full API for the multi-file store.
- [`jsonStore`](json-store.md) — single-file JSON store with locking.
- [Private file-store mode](file-store.md#private-mode) — credential-shaped variant.
- [JSON files](json.md) — lower-level `readJson` / `writeJson` helpers.
- [Atomic writes](atomic.md) — what `fileStore` and `jsonStore` use under the hood.
